/**
 * The panel's own end-to-end run (plan, subtask `e2e`: "Open Inicio and check that
 * every figure equals `GET /panel`, read in the same run"), against the real
 * backend, through the built front alone (PRD, M1: "no `curl` at any point").
 *
 * `flow.spec.ts`, `sales.spec.ts`, `payments.spec.ts` and `catalog.spec.ts` cover
 * everything offered before this task; this file seeds, through the front, exactly
 * what `results.md`'s PRD needs a figure for — a priced variety, a purchase, a sale
 * left owing, a sale paid on the spot, an expense — then proves Inicio (now the
 * panel) shows nothing it did not read from `GET /panel` in this same run: every
 * figure, across Hoy, Semana and Mes, and the "Owed to you" teaser's own navigation
 * (PRD, "No curl" metric: "opens Inicio, switches across the three periods, opens
 * Te deben from the block and a customer from the teaser").
 *
 * The screen's own figures are never recomputed here from the seed (plan invariant:
 * "No screen does arithmetic ... on an amount from the API") — this file only
 * formats the one `GET /panel` answer it fetches directly and compares that text to
 * what Inicio renders, the same way `catalog.spec.ts` compares the clipboard to
 * `GET /catalog`'s own text.
 *
 * `consoleMessages` is asserted empty at the end, and the browser's own storage too
 * (CODING_STANDARDS.md section 9: no figure or customer name belongs in either) —
 * exactly like `payments.spec.ts`, since this run carries a customer name and
 * several amounts through the panel alone.
 */

import { CUSTOMER, CUSTOMERS, CUSTOMER_NEW, HOME, SALES, SALE_NEW, STOCK_ENTRY_NEW, VARIETIES, pathTo } from '../src/routes.js'
import { expectPath } from './helpers/url.js'
import { expect, test } from './fixtures.js'
import { signUpNewBusiness } from './helpers/signup.js'
import { setPriceDate } from './helpers/priceDate.js'
import { watchConsole } from './console.js'
import { openGastos } from './helpers/openMas.js'
import { fillSaleLine } from './helpers/sale.js'
import { expectOnlyTheThemeStored } from './helpers/storage.js'
import { uniqueTag } from './helpers/unique.js'
import { appendFileSync } from 'node:fs'

interface PanelPeriod {
  start: string
  end: string
  sales: number
  sales_count: number
  average_sale: number | null
  grams_sold: number
  grams_gifted: number
  cost_of_goods: number
  pending_cost: boolean
  expenses: number
  purchases: number
  profit: number
  cash: number
}

type Status = 'no_entries' | 'sold_out' | 'low' | 'ok'

interface PanelAnswer {
  periods: { today: PanelPeriod; week: PanelPeriod; month: PanelPeriod }
  debts: {
    total_owed: number
    sales_owing_count: number
    oldest: string | null
    teaser: { customer_id: number; name: string; balance: number; owing_since: string }[]
  }
  stock: {
    variety_id: number
    name: string
    grams: number
    status: Status
    sold_out_since: string | null
    threshold: number | null
    days_left: number | null
  }[]
}

function shortDate(iso: string): string {
  const [, month, day] = iso.split('-')
  return `${day}/${month}`
}

function pesos(amount: number): string {
  return `$ ${Math.round(amount).toLocaleString('es-AR')}`
}

function signedPesos(amount: number): string {
  const rounded = Math.round(amount)
  return rounded < 0 ? `−${pesos(Math.abs(rounded))}` : pesos(rounded)
}

function grams(value: number): string {
  return `${value.toLocaleString('es-AR', { maximumFractionDigits: 2 })} g`
}

function countLabel(count: number): string {
  return `${count} ${count === 1 ? 'sale' : 'sales'}`
}

/** `salesOwingCount`: the Te deben head's count line. */
function owingLabel(count: number): string {
  return `${countLabel(count)} owing`
}

// A local mirror of `web/src/components/MarcaEstado.tsx`'s own word table and
// `web/src/stock/detail.ts`'s `detailFor` — this file never imports `web/src`
// (every other e2e spec duplicates its own small formatters the same way), and
// every value fed through it below comes from the one `GET /panel` answer this
// run fetches, never invented.
const STATUS_WORD: Record<Status, string> = {
  no_entries: 'no entries',
  sold_out: 'sold out',
  low: 'low',
  ok: 'ok',
}

function detailFor(
  variety: { status: Status; sold_out_since: string | null; threshold: number | null },
  today: string,
): string {
  switch (variety.status) {
    case 'no_entries':
      return 'Add its first entry'
    case 'sold_out':
      return variety.sold_out_since === null
        ? 'No grams'
        : `No grams since ${formatDate(variety.sold_out_since, today)}`
    case 'low':
      return variety.threshold === null
        ? 'You are warned below the threshold'
        : `Avisás abajo de ${grams(variety.threshold)}`
    case 'ok':
      return 'At the pace of the last 30 days'
  }
}

/** `web/src/stock/detail.ts`'s own `sideNoteFor`: the one place `days_left`
 * itself shows, in `.fila-stock__insignia` — never in the detail line. The status word
 * is `MarcaEstado`'s, not this note's. */
function sideNoteFor(variety: { status: Status; days_left: number | null }): string | null {
  if (variety.days_left === null) return null
  return `${variety.days_left} days`
}

/** `web/src/format/dates.ts`'s own `formatDate`: dd/mm, or dd/mm/yyyy when the
 * year differs from `todayIso`'s. */
function formatDate(iso: string, todayIso: string): string {
  const [year] = iso.split('-')
  const [todayYear] = todayIso.split('-')
  return year === todayYear ? shortDate(iso) : `${shortDate(iso)}/${year}`
}

function parseIso(iso: string): { year: number; month: number; day: number } {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso)
  if (match === null) throw new Error(`not an ISO date: ${iso}`)
  const [, year, month, day] = match
  return { year: Number(year ?? ''), month: Number(month ?? ''), day: Number(day ?? '') }
}

function addDays(iso: string, delta: number): string {
  const { year, month, day } = parseIso(iso)
  const shifted = new Date(Date.UTC(year, month - 1, day) + delta * 86_400_000)
  return `${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth() + 1).padStart(2, '0')}-${String(shifted.getUTCDate()).padStart(2, '0')}`
}

function weekdayOf(iso: string): number {
  const { year, month, day } = parseIso(iso)
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay() // 0 = Sunday .. 6 = Saturday.
}

test('a seller sees the panel agree with GET /panel, across periods, from the front alone', async ({
  page,
}) => {
  const consoleMessages: string[] = []
  watchConsole(page, consoleMessages)
  // GH-288 LOCAL DIAGNOSIS (never committed).
  const DIAG = process.env.GH288_DIAG ?? '/tmp/gh288-diag.log'
  const diag = (line: string): void => appendFileSync(DIAG, `${Date.now()} ${line}\n`)
  const cdp = await page.context().newCDPSession(page)
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: Number(process.env.GH288_RATE ?? '4') })
  await page.addInitScript(() => {
    const w = window as unknown as { __hist: string[] }
    w.__hist = []
    for (const m of ['pushState', 'replaceState'] as const) {
      const orig = history[m].bind(history)
      history[m] = (state: unknown, unused: string, url?: string | URL | null) => {
        const r = state as Record<string, unknown> | null
        const marker = r === null || typeof r !== 'object' ? 'none' : 'toast' in r ? `toast:${String(r.toast)}` : 'notice' in r ? 'notice' : 'saleJustSaved' in r ? 'saved' : 'other'
        w.__hist.push(`${m} ${String(url)} ${marker}`)
        orig(state, unused, url)
      }
    }
  })
  page.on('request', (r) => { if (r.url().includes('/customers')) diag(`req ${r.method()} ${new URL(r.url()).pathname}`) })
  page.on('response', (r) => { if (r.url().includes('/customers')) diag(`resp ${r.status()} ${new URL(r.url()).pathname}`) })
  page.on('requestfinished', (r) => { if (r.url().includes('/customers')) diag(`fin ${new URL(r.url()).pathname}`) })

  const ownerEmail = `duena-panel-${uniqueTag()}@example.com`
  const businessName = `Flores del Panel ${uniqueTag()}`

  // Accept a new-business invitation.
  await signUpNewBusiness(page, { businessName, email: ownerEmail })
  await expect(page.locator('.encabezado__negocio')).toHaveText(businessName)

  // A priced variety.
  await page.goto(VARIETIES)
  await page.getByRole('link', { name: 'New variety' }).click()
  await page.getByLabel('Name').fill('Rosa')
  await page.getByRole('button', { name: 'Add the variety' }).click()
  await expect(page.getByText('Variety saved')).toBeVisible()
  await page.getByRole('link', { name: /Rosa/ }).click()
  await page.getByRole('link', { name: 'New price' }).click()
  // Backdated well before this run's own month (sales.spec.ts does the same for
  // Jazmín): the extra, month-only sale seeded below needs a price that reaches
  // back that far too.
  await setPriceDate(page, '2000-01-01')
  await page.getByLabel(/^List price/).fill('1000')
  await page.getByRole('button', { name: 'Save the price' }).click()
  await expect(page.getByText('Price saved')).toBeVisible()

  // A purchase: the "Origen" pill defaults to "Purchase" (`EntradaStock.tsx`).
  await page.goto(STOCK_ENTRY_NEW)
  await page.getByLabel('Grams').fill('50')
  await page.getByLabel('Variety').selectOption({ label: 'Rosa' })
  await expect(page.getByRole('button', { name: 'Purchase' })).toHaveAttribute('aria-pressed', 'true')
  await page.getByLabel('Total cost').fill('45000')
  await page.getByRole('button', { name: 'Save the entry' }).click()
  await expect(page.getByText('Entry saved')).toBeVisible()

  // A customer, for the sale left owing.
  await page.goto(CUSTOMER_NEW)
  await page.getByLabel('Phone').fill('+5491155550077')
  await page.getByLabel('Name').fill('Carla Pérez')
  await page.getByRole('button', { name: 'Save and use' }).click()
  await expectPath(page, CUSTOMER)
  diag('path-passed')
  try {
    await expect(page.getByText('Customer saved')).toBeVisible()
    diag('customer-saved OK')
  } catch (e) {
    const snap = await page.evaluate(() => ({
      hist: (window as unknown as { __hist: string[] }).__hist,
      state: ((): string => { const st = history.state as { usr?: Record<string, unknown> } | null; const u = st?.usr; return u === undefined || u === null ? 'no-usr' : Object.keys(u).join(',') })(),
      ready: document.readyState,
      path: location.pathname,
      loading: document.querySelector('[aria-busy], .cargando') !== null,
      status: [...document.querySelectorAll('[role=status]')].map((n) => n.className),
      heading: document.querySelector('[data-place=card-heading]') !== null,
      alert: [...document.querySelectorAll('[role=alert]')].map((n) => n.className),
      main: document.querySelector('main')?.className ?? 'none',
    }))
    diag(`MISS ${JSON.stringify(snap)} console=${JSON.stringify(consoleMessages.slice(-5))}`)
    await page.screenshot({ path: '/tmp/gh288-miss.png' })
    throw e
  }

  // A sale left owing, to Carla.
  await page.getByRole('link', { name: 'New sale to Carla Pérez' }).click()
  await expectPath(page, SALE_NEW)
  const todayIso = await page.getByLabel('Date').inputValue()
  await fillSaleLine(page, 1, { variety: 'Rosa', grams: '5' })
  await page.getByRole('radio', { name: 'Owing' }).check()
  await page.getByRole('button', { name: 'Save sale' }).click()
  await expect(page.getByText('Sale saved')).toBeVisible()

  // A sale paid on the spot, no customer.
  await page.goto(SALES)
  await page.getByRole('link', { name: 'New sale' }).click()
  await fillSaleLine(page, 1, { variety: 'Rosa', grams: '3' })
  await page.getByRole('radio', { name: 'Cash' }).check()
  await page.getByRole('button', { name: 'Save sale' }).click()
  await expect(page.getByText('Sale saved')).toBeVisible()

  // Two more sales, dated at the start of this week and the start of this month —
  // so Hoy, Semana and Mes can differ by more than their range label, whatever day
  // this run happens to land on. `mondayIso` and `monthStartIso` are each today or
  // earlier, never future (a week's or a month's start never comes after the today
  // it contains), so both are always safe to seed; deduplicated against `todayIso`
  // and each other, so a day that already carries a sale (today being Monday, or
  // the 1st of the month) is never seeded twice. Whichever of the two falls outside
  // the current month (when the week crosses a month boundary, as it does whenever
  // today is early in the month) widens Semana past Mes; whichever falls outside
  // the current week widens Mes past Semana — between the two, at least one real
  // difference from Hoy's own figures is guaranteed.
  // Seeded directly, through the same session's own `page.request` (`sales.spec.ts`
  // already seeds this way for its own period checks) — this is the panel's own
  // seam, "the end-to-end front run", not a `curl` shortcut: same browser, same
  // cookies, no second process.
  const monthStartIso = `${todayIso.slice(0, 7)}-01`
  const mondayOffset = weekdayOf(todayIso) === 0 ? -6 : 1 - weekdayOf(todayIso)
  const mondayIso = addDays(todayIso, mondayOffset)
  const extraDatesIso = [...new Set([mondayIso, monthStartIso])].filter((iso) => iso !== todayIso)
  if (extraDatesIso.length > 0) {
    const varietiesAnswer: { id: number; name: string }[] = await (
      await page.request.get(`/varieties?on=${todayIso}`)
    ).json()
    const rosaId = varietiesAnswer.find((variety) => variety.name === 'Rosa')?.id
    if (rosaId === undefined) throw new Error('Rosa missing from GET /varieties?on=')
    for (const dateIso of extraDatesIso) {
      const extraResponse = await page.request.post('/sales', {
        data: {
          date: dateIso,
          customer_id: null,
          shipping_charged: 0,
          note: null,
          payment: 'cash',
          lines: [{ variety_id: rosaId, grams: '1', gift: false, special_price: null }],
        },
      })
      expect(extraResponse.ok()).toBe(true)
    }
  }

  // An expense, in the business's own default "Other" category.
  await openGastos(page)
  await page.getByRole('link', { name: 'Add expense' }).click()
  await page.getByLabel('Category').selectOption({ label: 'Other' })
  await page.getByLabel('Amount').fill('1500')
  await page.getByLabel('Details').fill('Bolsas de regalo')
  await page.getByRole('button', { name: 'Save the expense' }).click()
  await expect(page.getByText('Expense saved')).toBeVisible()

  // `GET /panel`, read in this same run: the one answer Inicio must agree with,
  // figure for figure, never recomputed here (plan invariant).
  const panel = await page.evaluate(() =>
    fetch('/panel', { credentials: 'include' }).then((response) => response.json() as Promise<PanelAnswer>),
  )

  await page.goto(HOME)
  await expect(page.locator('.encabezado__titulo')).toHaveText('Home')

  async function assertPeriod(period: PanelPeriod, rangeText: string, showsResults: boolean): Promise<void> {
    await expect(page.locator('.inicio__periodos .pie')).toContainText(rangeText)
    await expect(page.locator('.panel-ventas .cifra-xl')).toHaveText(pesos(period.sales))
    if (showsResults) {
      await expect(
        page.getByRole('group', { name: 'Profit', exact: true }).locator('.panel-resultados__valor--acento'),
      ).toHaveText(signedPesos(period.profit))
      await expect(
        page.getByRole('group', { name: 'Cash', exact: true }).locator('.panel-resultados__valor'),
      ).toHaveText(signedPesos(period.cash))
      await expect(
        page.getByRole('group', { name: 'Cost of goods sold', exact: true }).locator('.panel-lista__valor'),
      ).toHaveText(pesos(period.cost_of_goods))
      await expect(
        page.getByRole('group', { name: 'Expenses', exact: true }).locator('.panel-lista__valor'),
      ).toHaveText(pesos(period.expenses))
      await expect(
        page.getByRole('group', { name: 'You gave away', exact: true }).locator('.panel-lista__valor'),
      ).toHaveText(grams(period.grams_gifted))
      await expect(
        page.getByRole('group', { name: 'Flower purchases', exact: true }).locator('.panel-lista__valor'),
      ).toHaveText(pesos(period.purchases))
      // "includes pending cost", under both Cost of goods sold and Ganancia only,
      // never under Caja (plan, PRD: "Caja never carries it").
      await expect(page.getByText('includes pending cost')).toHaveCount(period.pending_cost ? 2 : 0)
    } else {
      // Hoy is only what can be acted on (results.md): no result figure at all.
      for (const label of ['Profit', 'Cash', 'Cost of goods sold', 'Expenses', 'You gave away', 'Flower purchases']) {
        await expect(page.locator('main').getByText(label, { exact: true })).toHaveCount(0)
      }
      await expect(page.getByText('includes pending cost')).toHaveCount(0)
    }

    // "Vendiste ..."'s own subtitle: count, average (absent with no sales) and
    // grams sold (`Inicio.tsx`'s own `salesSubtitle`).
    const count = countLabel(period.sales_count)
    const gramsSoldText = grams(period.grams_sold)
    const subtitle =
      period.average_sale === null
        ? `${count} · ${gramsSoldText}`
        : `${count} · average ${pesos(period.average_sale)} · ${gramsSoldText}`
    await expect(page.locator('.panel-ventas .pie')).toHaveText(subtitle)
  }

  // Hoy: the panel opens here (plan, "Front").
  await expect(page.getByRole('button', { name: 'Today', exact: true })).toHaveAttribute('aria-pressed', 'true')
  await assertPeriod(panel.periods.today, shortDate(todayIso), false)

  // Semana.
  await page.getByRole('button', { name: 'Week' }).click()
  await assertPeriod(panel.periods.week, `${shortDate(panel.periods.week.start)} – ${shortDate(panel.periods.week.end)}`, true)

  // Mes.
  await page.getByRole('button', { name: 'Month' }).click()
  await assertPeriod(panel.periods.month, `${shortDate(panel.periods.month.start)} – ${shortDate(panel.periods.month.end)}`, true)

  // Back to Hoy for the rest of the run.
  await page.getByRole('button', { name: 'Today', exact: true }).click()

  // Lo que te queda: Rosa's own row, straight from the fetched answer — grams,
  // status (shape and word), the detail line, and the side note, which is the
  // one place days left itself shows (`sideNoteFor`, never the detail line).
  const rosa = panel.stock.find((row) => row.name === 'Rosa')
  if (rosa === undefined) throw new Error('Rosa missing from GET /panel stock')
  const rosaRow = page.locator('.fila-stock').filter({ hasText: 'Rosa' })
  await expect(rosaRow.locator('.fila-stock__gramos')).toHaveText(grams(rosa.grams))
  await expect(rosaRow.locator('.marca-estado')).toHaveClass(new RegExp(`marca-estado--${rosa.status}\\b`))
  await expect(rosaRow.locator('.marca-estado__palabra')).toHaveText(STATUS_WORD[rosa.status])
  await expect(rosaRow.locator('.fila-stock__detalle')).toHaveText(detailFor(rosa, todayIso))
  const rosaSideNote = sideNoteFor(rosa)
  if (rosaSideNote === null) {
    await expect(rosaRow.locator('.fila-stock__insignia')).toHaveCount(0)
  } else {
    await expect(rosaRow.locator('.fila-stock__insignia')).toHaveText(rosaSideNote)
  }

  // Te deben: the block shows the fetched total, count and oldest date, and the
  // teaser's own balance and "desde dd/mm" — all read, never computed here.
  await expect(page.locator('.bloque-deben .cifra-xl')).toHaveText(pesos(panel.debts.total_owed))
  // The head's two lines, each its own element: the count (`salesOwingCount`) and the
  // oldest date. Each teaser row carries its own "desde dd/mm", inside its own link.
  await expect(page.locator('.bloque-deben__cuenta')).toHaveText(owingLabel(panel.debts.sales_owing_count))
  if (panel.debts.oldest !== null) {
    await expect(page.locator('.bloque-deben__desde')).toHaveText(`since ${shortDate(panel.debts.oldest)}`)
  }

  const [teaserRow] = panel.debts.teaser
  if (teaserRow === undefined) throw new Error('empty teaser in GET /panel')
  const teaserLink = page.locator('.bloque-deben__fila').filter({ hasText: teaserRow.name })
  await expect(teaserLink).toContainText(pesos(teaserRow.balance))
  await expect(teaserLink).toContainText(`since ${shortDate(teaserRow.owing_since)}`)

  // Opens Te deben from the block's own heading, then goes back to Inicio.
  await page.getByRole('link', { name: 'Owed to you' }).click()
  await expectPath(page, CUSTOMERS)
  await expect(page.locator('.ventas__resumen .cifra-xl')).toHaveText(pesos(panel.debts.total_owed))
  await page.goBack()
  await expectPath(page, HOME)
  await expect(page.locator('.encabezado__titulo')).toHaveText('Home')

  // The teaser: Carla's own row, opening her card.
  await page.getByRole('link', { name: teaserRow.name }).first().click()
  await expect(page).toHaveURL(new RegExp(`${pathTo(CUSTOMER, { id: teaserRow.customer_id })}$`))
  // On a computer the list sits beside the card and has its own title: read the card's (the pane
  // without the search box).
  await expect(
    page.locator('main').filter({ hasNot: page.getByLabel('Search customer') }).locator('.encabezado__titulo'),
  ).toHaveText(teaserRow.name)
  await expect(page.locator('.ficha-deuda', { hasText: new RegExp(`Owes you\\s*${pesos(teaserRow.balance).replace(/[$.]/g, '\\$&')}`) })).toBeVisible()

  // Nothing personal or technical reaches the console or the browser's own storage
  // (CODING_STANDARDS.md section 9) — a customer's name and several amounts moved
  // through this run's panel alone.
  await expectOnlyTheThemeStored(page)
  expect(consoleMessages).toEqual([])
})
